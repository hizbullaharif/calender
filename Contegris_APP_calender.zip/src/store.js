import { createStore } from "redux";
import Reducer from "./reducers/index";
const store = createStore(
  Reducer,
  window.devToolsExtension ? window.devToolsExtension() : (f) => f
);

export default store;
