import { combineReducers } from "redux";
import holidays from "./holidays_reducer";

const Reducer = combineReducers({
  holidays: holidays,
});

export default Reducer;
