import axios from "axios";
export function holidays1(year) {
  // const fetchHolidays = async () => {
  //   // eslint-disable-next-line react-hooks/rules-of-hooks
  //   const response = await axios
  //     .get(
  //       "https://calendarific.com/api/v2/holidays?&api_key=684742d1b51254d26b78d473f1ec4119408b2968&country=pk&year=2019"
  //     )
  //     .catch((err) => {
  //       console.log(err);
  //     });
  //   console.log(response.data.response.holidays);
  // };

  // const req = fetchHolidays();
  const request = axios
    .get(
      "https://calendarific.com/api/v2/holidays?&api_key=684742d1b51254d26b78d473f1ec4119408b2968&country=pk&year=2019"
    )
    .then((response) => {
      return response.data.response;
    });

  return {
    type: "holidays",
    payload: request,
  };
}
