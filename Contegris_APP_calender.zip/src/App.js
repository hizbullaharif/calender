// React hooks
import { useEffect, useState } from "react";
// React big calender library with css
import { Calendar, momentLocalizer } from "react-big-calendar";
import "react-big-calendar/lib/css/react-big-calendar.css";

import moment from "moment";
// Import Redux
import { useDispatch } from "react-redux";
import { holidays1 } from "./actions";

// For Fetching data
import axios from "axios";

const localizer = momentLocalizer(moment);

function App() {
  //Array for initial state
  const events_ = [
    {
      title: "",
      allDay: true,
      start: new Date(),
      end: new Date(),
    },
  ];
  // events and Countries
  const [events, setEvents] = useState(events_);
  const [country, setCountry] = useState("pk");
  // Fetching All data from the Calenderia Server for pakistan and Year 2021
  const fetchHolidays = async (country = "pk") => {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    const response = await axios
      .get(
        `https://calendarific.com/api/v2/holidays?&api_key=684742d1b51254d26b78d473f1ec4119408b2968&country=${country}&year=2021`
      )
      .catch((err) => {
        console.log(err);
      });
    const holidays_array = response.data.response.holidays;
    holidays_array.forEach((item, index) => {
      events_.push({
        title: item.name,
        allDay: true,
        start: new Date(item.date.iso),
        end: new Date(item.date.iso),
      });
    });
    setEvents(events_);
  };

  // update all data in change Country
  const handleChange = (event) => {
    setCountry(event.target.value);
    fetchHolidays(event.target.value);
  };

  // calling use Effect hook for fuction berfore render
  useEffect(() => {
    fetchHolidays();
  }, []);

  /**
   *
   * Using Redux
   *
   */

  // const dispatch = useDispatch();
  // const data1 = dispatch(holidays1(2019));
  // console.log(data1.payload);
  // fetch all data from holidays withput redux

  return (
    <>
      {/* Country selection */}
      {/* Calenderia api did not provide list of countries */}
      {/* I have used some Selected countries */}
      Country :
      <select value={country} onChange={handleChange}>
        <option value="af">Afghanistan</option>
        <option value="pk">pakistan</option>
        <option value="in">india</option>
        <option value="bd">Bangladesh</option>
      </select>
      {/* Calender component */}
      <Calendar
        localizer={localizer}
        events={events}
        startAccessor="start"
        endAccessor="end"
        style={{ margin: 10, height: 500, width: 700 }}
      />
    </>
  );
}

export default App;
